angular.module('app')

.controller('FeedbackController', ['$scope', function($scope) {

}]);