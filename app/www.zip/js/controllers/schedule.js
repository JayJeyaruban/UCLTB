angular.module('app')

.controller('ScheduleController', ['$scope', function($scope) {

}])
